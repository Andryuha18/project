- 👋 Hi, I’m @Andryuha18
- 👀 I’m interested in ...
- 🌱 I’m currently learning ...
- 💞️ I’m looking to collaborate on ...
- 📫 How to reach me ...

<!---
Andryuha18/Andryuha18 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->

---
Финальный проект
---
* Минимум 3 страницы или одна большая
* SASS Обязательно!
* Блочная модель (margn, padding)
* Элементы на Flex-ах
* Элементы на Grid-ах
* Анимации (@keyframes, hover)
* Адаптив (@media)
* Позиционирование
* Формы
* Лучше section
* Списки
* Медиа элементы (картинки, видео(из ютуба))
* Можно написать проект на Tailwind
* Можно написать проект на коленке :)
* Таблица (зависит от макета)
* Макеты Figma
* Не использовать Materialize и Bootstrap

Можно использовать JavaScript



[https://t.me/FigmaMaket]([https://t.me/FigmaMaket]())

[https://t.me/figma2html]([https://t.me/figma2html]())

[https://t.me/true_figma](https://t.me/true_figma)

---

Сдача проекта - 16.09.2023

2 Ссылки на GitHub, на сам репозиторий и на работающий проект

---
